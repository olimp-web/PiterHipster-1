# Тут что мы получаем при обращении к конкретному товару
#
#
# {
#     "data": {
#         "categories": [
#             {
#                 "id": 1,
#                 "Title": "Попка корги",
#                 "Description": "Туда можно засунуть ценные вещички :З",
#                 "Price": 2000.0,
#                 "photos": [
#                     {
#                         "Direction": "dsfgfgsdfgsf",
#                         "alt": "picture"
#                     },
#                     {
#                         "Direction": "В зеленолупье",
#                         "alt": "picture"
#                     }
#                 ],
#                 "modifications": [
#                     {
#                         "color": "red",
#                         "size": "S"
#                     },
#                     {
#                         "color": "orange",
#                         "size": "L"
#                     },
#                     {
#                         "color": "green",
#                         "size": "S"
#                     }
#                 ]
#             }
#         ]
#     }
# }
#
#
# Тут что мы получаем на главной страничке при вызове списка категорий
#
# {
#     "data": {
#         "categories": [
#             {
#                 "id": 1,
#                 "Title": "Щеночки"
#             },
#             {
#                 "id": 2,
#                 "Title": "Котятки"
#             }
#         ]
#     }
# }
#
# товары в каталоге
#
# {
#     "data": {
#         "goods": [
#             {
#                 "id": 1,
#                 "Title": "Попка корги",
#                 "Price": 2000.0,
#                 "photos": [
#                     {
#                         "Direction": "dsfgfgsdfgsf",
#                         "alt": "picture"
#                     }
#                 ]
#             }
#         ]
#     }
# }
